package com.example.sarahtomlinson_inventoryfinalproject.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.sarahtomlinson_inventoryfinalproject.models.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

// SQL helper class for ItemEntry objects
public class SQLiteItemDBHelper extends SQLiteOpenHelper {


    private static final int DB_VERSION = 2;
    private static final String DB_NAME = "ItemsData.DB";
    private static final String ITEM_TABLE_NAME = "ItemsTable";

    private static final String COLUMN_0_ID = "id";
    private static final String COLUMN_1_USER_ID = "userId";
    private static final String COLUMN_2_DESCRIPTION = "description";
    private static final String COLUMN_3_QUANTITY = "quantity";

    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            ITEM_TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_USER_ID + " INTEGER, " +
            COLUMN_2_DESCRIPTION + " VARCHAR, " +
            COLUMN_3_QUANTITY + " INTEGER"
            + ");";

    public SQLiteItemDBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + ITEM_TABLE_NAME);
        onCreate(db);
    }


    // Iterate through readable DB and return count of items
    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + ITEM_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int totalItems = cursor.getCount();
        cursor.close();

        return totalItems;
    }


    // ADD ItemEntry
    public void createItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_USER_ID, item.getUserId());
        values.put(COLUMN_2_DESCRIPTION, item.getDescription());
        values.put(COLUMN_3_QUANTITY, item.getQuantity());

        db.insert(ITEM_TABLE_NAME, null, values);
        db.close();
    }

    // READ ItemEntry
    public Item readItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(ITEM_TABLE_NAME,
                new String[] { COLUMN_0_ID, COLUMN_1_USER_ID, COLUMN_2_DESCRIPTION, COLUMN_3_QUANTITY }, COLUMN_0_ID + " = ?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        Item item = new Item();
        item.setId(cursor.getInt(0));
        item.setUserId(cursor.getInt(1));
        item.setDescription(cursor.getString(2));
        item.setQuantity(cursor.getInt(3));

        cursor.close();
        return item;
    }

    // UPDATE ItemEntry
    public int updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_2_DESCRIPTION, item.getDescription());
        values.put(COLUMN_3_QUANTITY, item.getQuantity());

        return db.update(ITEM_TABLE_NAME, values, COLUMN_0_ID + " = ?", new String[] { String.valueOf(item.getId()) });
    }

    // DELETE ItemEntry
    public void deleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(ITEM_TABLE_NAME, COLUMN_0_ID + " = ?", new String[] { String.valueOf(item.getId()) });
        db.close();
    }


    // Return a List<ItemEntry> of all items for displaying
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();

        // Select everything in SQLite db
        String selectQuery = "SELECT * FROM " + ITEM_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // iterate through every row, adding items
        if (cursor.moveToFirst()) {
            do {

                Item item = new Item();
                item.setId(cursor.getInt(0));
                item.setUserId(cursor.getInt(1));
                item.setDescription(cursor.getString(2));
                item.setQuantity(cursor.getInt(3));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

    public List<Item> getItemsByUser(int userId) {

        List<Item> itemList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                ITEM_TABLE_NAME,
                null,
                COLUMN_1_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                null
        );

        if(cursor.moveToFirst()) {

            do {

                Item item = new Item();

                item.setId(cursor.getInt(0));
                item.setUserId(cursor.getInt(1));
                item.setDescription(cursor.getString(2));
                item.setQuantity(cursor.getInt(3));

                itemList.add(item);

            } while(cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

}
