package com.example.sarahtomlinson_inventoryfinalproject.repository;

import android.content.Context;

import com.example.sarahtomlinson_inventoryfinalproject.database.SQLiteItemDBHelper;
import com.example.sarahtomlinson_inventoryfinalproject.models.Item;

import java.util.List;

// Repository layer that acts as the middle man between the app and the SQLite item database
public class ItemRepository {

    private final SQLiteItemDBHelper dbHelper;

    public ItemRepository(Context context) {
        dbHelper = new SQLiteItemDBHelper(context);
    }

    // Get all items from the repository
    public List<Item> getAllItems() {
        return dbHelper.getAllItems();
    }

    public void createItem(Item item) {
        dbHelper.createItem(item);
    }

    public Item readItem(int id) {
        return dbHelper.readItem(id);
    }

    public List<Item> getItemsByUser(int userId) {
        return dbHelper.getItemsByUser(userId);
    }

    public int updateItem(Item item) {
        return dbHelper.updateItem(item);
    }

    public void deleteItem(Item item) {
        dbHelper.deleteItem(item);
    }
}