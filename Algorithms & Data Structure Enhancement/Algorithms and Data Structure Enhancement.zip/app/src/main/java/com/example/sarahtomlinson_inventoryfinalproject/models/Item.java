package com.example.sarahtomlinson_inventoryfinalproject.models;

public class Item {

    int id;
    String description;
    Integer quantity;

    // Model class for an item stored in inventory
    public Item() {
        super();
    }

    public Item(int id, String description, Integer quantity) {
        this.id = id;
        this.description = description;
        this.quantity = quantity;
    }

    public Item(String description, Integer quantity) {
        this.description = description;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}