package com.example.sarahtomlinson_inventoryfinalproject.repository;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.sarahtomlinson_inventoryfinalproject.database.SQLiteDBHelper;
import com.example.sarahtomlinson_inventoryfinalproject.models.User;

//Repository layer handles user-related database operations
public class UserRepository {

    private final SQLiteDBHelper dbHelper;

    public UserRepository(Context context) {

        dbHelper = new SQLiteDBHelper(context);
    }

    //Repository Layer that acts as intermediary between database and Activities
    public void createUser(User user) {

        dbHelper.createUser(user);
    }

    public User readUser(int id) {

        return dbHelper.readUser(id);
    }

    public int updateUser(User user) {

        return dbHelper.updateUser(user);
    }

    public void deleteUser(User user) {

        dbHelper.deleteUser(user);
    }

    // Check if username already exists in database
    public boolean checkUsernameAlreadyExists(String username){

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(
                SQLiteDBHelper.USERS_TABLE_NAME,
                null,
                SQLiteDBHelper.COLUMN_1_NAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean  exists = cursor.moveToFirst();

        cursor.close();
        db.close();

        return exists;
    }
}