package com.example.sarahtomlinson_inventoryfinalproject.service;

import com.example.sarahtomlinson_inventoryfinalproject.models.User;
import com.example.sarahtomlinson_inventoryfinalproject.repository.UserRepository;

// The service layer handles validation and user registration logic
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // Validate input and register User
    public String registerUser(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            return "Username is Empty";
        }

        if (password == null || password.trim().isEmpty()) {
            return "Password is Empty";
        }

        if (userRepository.checkUsernameAlreadyExists(username)) {
            return "Username Exists";
        }

        User user = new User(username,password);
        userRepository.createUser(user);

        return "SUCCESS";
    }
}
