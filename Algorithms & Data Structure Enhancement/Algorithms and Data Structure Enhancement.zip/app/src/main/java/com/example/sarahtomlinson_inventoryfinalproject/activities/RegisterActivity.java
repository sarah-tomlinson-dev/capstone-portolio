package com.example.sarahtomlinson_inventoryfinalproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sarahtomlinson_inventoryfinalproject.R;
import com.example.sarahtomlinson_inventoryfinalproject.repository.UserRepository;
import com.example.sarahtomlinson_inventoryfinalproject.service.UserService;

// RegisterActivity now handles UI interactions Only.
// Validation and database functions are moved to the
// service and repository layers.
public class RegisterActivity extends AppCompatActivity {

    Button RegisterButton;
    EditText UsernameHolder, PasswordHolder;
    UserRepository userRepository;
    UserService userService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        UsernameHolder = findViewById(R.id.edit_username);
        PasswordHolder = findViewById(R.id.edit_password);
        RegisterButton = findViewById(R.id.button_register);
        userRepository = new UserRepository(this);
        userService = new UserService(userRepository);

        // Adding click listener to register Register Button
        RegisterButton.setOnClickListener(view -> {

            //Convert UsernameHolder & PasswordHolder to string
            String username = UsernameHolder.getText().toString().trim();
            String password = PasswordHolder.getText().toString().trim();

            String result = userService.registerUser(username, password);

            if (result.equals("SUCCESS")) {
            Toast.makeText(
                    this,
                    "User Registered",
                    Toast.LENGTH_LONG
            ).show();

            startActivity(
                    new Intent(RegisterActivity.this, LoginActivity.class)
            );
            finish();
            }
            else {
                Toast.makeText(this, result, Toast.LENGTH_LONG).show();
            }
        });
    }
}