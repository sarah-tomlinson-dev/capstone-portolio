package com.example.sarahtomlinson_inventoryfinalproject.service;

import com.example.sarahtomlinson_inventoryfinalproject.models.Item;
import com.example.sarahtomlinson_inventoryfinalproject.repository.ItemRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

// Service layer, responsible for business logic around items in inventory
// Includes validation and sorting
public class ItemService {

    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public String addItem(String description, int quantity) {

        if (description == null || description.trim().isEmpty()) {
            return "Description Empty";
        }

        if (quantity < 0) {
            return "Invalid Quantity";
        }

        Item item = new Item(description, quantity);

        itemRepository.createItem(item);

        return "Item Added";
    }

    public List<Item> getItemsSortedByQuantity() {

        List<Item> items = itemRepository.getAllItems();

        // Sort items in ascending order based on inventory quantity
        Collections.sort(items,
                Comparator.comparingInt(Item::getQuantity));

        return items;
    }

    // Returns all items whose quantity falls below a given threshold
    public List<Item> getLowStockItems(int threshold) {

        List<Item> allItems = itemRepository.getAllItems();

        List<Item> lowStockItems = new ArrayList<>();

        for (Item item : allItems) {

            if (item.getQuantity() <= threshold) {
                lowStockItems.add(item);
            }
        }

        return lowStockItems;
    }

    // Search inventory items by description keyword
    public List<Item> searchItems(String keyword) {

        List<Item> allItems = itemRepository.getAllItems();

        List<Item> matchingItems = new ArrayList<>();

        for (Item item : allItems) {

            if (item.getDescription().toLowerCase()
                    .contains(keyword.toLowerCase())) {

                matchingItems.add(item);
            }
        }

        return matchingItems;
    }
}